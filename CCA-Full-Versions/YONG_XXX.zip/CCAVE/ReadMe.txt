GUI COLOSSAL CAVE
� 2006 Presented by www.Intelligent-Digital.com
By C.Yong

Please visit website: www.intelligent-digital.com
For any comment and query please visit:
http://www.intelligent-digital.com/feedback.htm


SYSTEM AND DRIVERS REQUIREMENTS   

1. Runs on Windows 98/NT/ME/XP/2000/Sever2003
2. Following Driver is needed for all versions of windows  (98/NT/XP/2000/Server2003): 
    Microsoft .NET framework 1.1 Driver   
3. Additional drivers needed for Windows 98/NT/ME: 
     MDAC2.7 Microsoft Data Access Components
Drivers as mentioned in 2 and 3 can be downloaded from Microsoft Website.
4. A sound card
5. Recommended Screen resolution: 800x600 SVGA (Higher resolution is all right)

INSTALLATION
	1. Unpack this zip file into a temporary directory 
	2. Run the SETUP.EXE program and follow the instructions.
	3. You're done!

UNINSTALLATION
	1. Go to Add / Remove Programs in Control Panel
	2. Select the program you would like to uninstall

ENJOY!

CONTACT:
Website: www.intelligent-digital.com
For any comment and query please visit:
http://www.intelligent-digital.com/feedback.htm