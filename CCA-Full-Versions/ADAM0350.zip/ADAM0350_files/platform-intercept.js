var amcnInterceptConfig = {
	intercept: false,
	cookie: false,
	playLivestream: true, // Allow livestream playback; Note: intercept is also hidden by css in _video-player.scss.
	playShortform: true, // Note: intercept is also hidden by css in _video-player.scss.
	playLongform: true,
	playMovies: true,
	message: {}
};

var premiereConfig = {
	premiereEnabled: true,
	message: {
		pre: ('This content is not available for viewing yet.'),
		restricted: ('This content is not available for viewing yet.'),
		default: ('This content is not available for viewing yet.')
	}
};

(function($){
	/* Click Event: Player Intercept - launch iOS app store */
	$(document).on('click', '#platform-intercept .amcn_intercept_ios_app', function(){
	    _ca.trackEvent2({
	      'category':'player_intercept',
	      'action': 'itunes_app_store',
	      'label': 'download_app_link'
	    });
	});

	/* Click Event: Player Intercept - launch Google Play store */
	$(document).on('click', '#platform-intercept .amcn_intercept_android_app', function(){
	    _ca.trackEvent2({
	      'category':'player_intercept',
	      'action': 'google_play_store',
	      'label': 'download_app_link'
	    });
	});

	/* Click Event: Player Intercept - dismiss app promotion */
	$(document).on('click', '#platform-intercept .dismiss', function(){
	    _ca.trackEvent2({
	      'category':'player_intercept',
	      'action': 'dismiss_clickthrough',
	      'label': 'download_app_link'
	    });
	});

})(window.jQuery);