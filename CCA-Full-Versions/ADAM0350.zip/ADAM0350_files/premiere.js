var AMCNUI = AMCNUI || {};

(function ($) {

	AMCNUI.Premiere = AMCNUI.Premiere || {

		/**
		 * Renders existing template markup into modal
		 *
		 * @param id string - The CSS ID of the template element
		 * @param settings object - Settings for the modal
		 * @return undefined
		 */
		init: function () {

			var authn_cookie = amcnPlatformConfig.network + '-v4-tve-authn';
			var app_state_cookie = amcnPlatformConfig.network + '-tve-app_state';

			//listen for pre-flight check
			$(document).on("amcn.adobe.userstate.events.v1", function (event, data) {
				
				//if premiere provider (only xfinity right now)
				if (readCookie(authn_cookie) === 'Comcast_SSO' && data.userLevel === 'adfree') {
					//fire off premiere
					AMCNUI.Premiere.addBodyClass("adobe-premiere");
					createCookie(app_state_cookie, 'premiere', 1);

				} else if (readCookie(authn_cookie) === 'Comcast_SSO' && data.userLevel === 'auth') {
					// fire off pot premiere
					AMCNUI.Premiere.addBodyClass("adobe-potpremiere");
					createCookie(app_state_cookie, 'potpremiere', 1);

				} else if (readCookie(authn_cookie) !== 'Comcast_SSO' && data.userLevel === 'auth') {
					// fire off pot premiere
					AMCNUI.Premiere.addBodyClass("adobe-auth");
					createCookie(app_state_cookie, 'auth', 1);

				} else if (readCookie(authn_cookie) === 'NonAuth' || readCookie(authn_cookie) == null) {
					// fire off default user
					AMCNUI.Premiere.addBodyClass("adobe-unauth");
					createCookie(app_state_cookie, 'unauth', 1);

				}

			});

            AMCNUI.Premiere.updateVideoExtras();

			// Request Testing
			// var testShowName = 'fear-the-walking-dead';
			// var testSeasonNum = 3;
			// var testEpisodeNum = 13;
			//
			// AMCNUI.Premiere.getShow(testShowName);
			// AMCNUI.Premiere.getSeasons(testShowName);
			// AMCNUI.Premiere.getSeason(testShowName, testSeasonNum);
			// AMCNUI.Premiere.getEpisodes(testShowName, testSeasonNum);
			// AMCNUI.Premiere.getEpisode(testShowName, testSeasonNum, testEpisodeNum);
			// AMCNUI.Premiere.getVideoEpisode(testShowName, testSeasonNum, testEpisodeNum);
			// AMCNUI.Premiere.getVideoExtras(testShowName, testSeasonNum, testEpisodeNum);
		},

		addBodyClass: function (bodyclass) {
			//add bodyclass to key off of
			$('body').addClass(bodyclass);
		},

		removeBodyClass: function (bodyclass) {
			//add bodyclass to key off of
			$('body').removeClass(bodyclass);
		},

		updateHome: function () {

		},

		updateShow: function () {

		},

		updateContenDetail: function () {

		},

		updateVideo: function () {

		},

        updateVideoExtras: function () {
            $("body:not(.adobe-premiere) a.amcp-premiere-video").click(function(){
                return false;
            });

            $( '.amcn-carrington-video-loop .module-title.amcp-premiere' ).html( "Premiere exclusive extras" );

            // $(".video-loop .slick-track").each(function () {
            //     var c = jQuery.makeArray($("article", $(this)));
            //     c.sort(function (a, b) {
            //         a = $(a).hasClass("amcp-premiere");
            //         b = $(b).hasClass("amcp-premiere");
            //         return b - a
            //     });
            //     $(this).empty().prepend(c);
            // });




        },

		/**
		 * Pad a string with zeros
		 *
		 * @param string - the string to pad
		 * @param max - the max length the string should be
		 * @returns {string} - the padded string
		 */
		strPad: function (string, max) {
			var string = string.toString();
			return string.length < max ? AMCNUI.Premiere.strPad("0" + string, max) : string;
		},

		makeRequest: function (path, data) {
			var defaults = {
				device: 'web',
				publish_state: 'restricted'
			};

			return $.ajax({
				url: 'https://amc-api-br.svc.ds.amcn.com/v1/public/feed/' + path,
				data: $.extend(defaults, data),
				dataType: 'json',
				error: function (jqXHR) {
					console.log('error ' + jqXHR.status);
				}
			});
		},

		getShow: function (showName) {
			return AMCNUI.Premiere.makeRequest('getShow', {
				show: showName
			});
		},

		getSeasons: function (showName) {
			return AMCNUI.Premiere.makeRequest('getSeasons', {
				show: showName
			});
		},

		getSeason: function (showName, seasonNum) {
			return AMCNUI.Premiere.makeRequest('getSeasons', {
				show: showName,
				season: 'season-' + seasonNum
			});
		},

		getEpisodes: function (showName, seasonNum) {
			return AMCNUI.Premiere.makeRequest('getEpisodes', {
				show: showName,
				season: 'season-' + seasonNum
			});
		},

		getEpisode: function (showName, seasonNum, episodeNum) {
			return AMCNUI.Premiere.makeRequest('getEpisode', {
				show: showName,
				season: 'season-' + seasonNum,
				episode: 'episode-' + AMCNUI.Premiere.strPad(episodeNum, 2)
			});
		},

		getVideoEpisode: function (showName, seasonNum, episodeNum) {
			return AMCNUI.Premiere.makeRequest('getVideoEpisode', {
				show: showName,
				season: 'season-' + seasonNum,
				episode: 'episode-' + AMCNUI.Premiere.strPad(episodeNum, 2)
			});
		},

		getVideoExtras: function (showName, seasonNum, episodeNum) {
			return AMCNUI.Premiere.makeRequest('getVideoExtras', {
				show: showName,
				season: 'season-' + seasonNum,
				episode: 'episode-' + AMCNUI.Premiere.strPad(episodeNum, 2)
			});
		}
	};

	$(document).ready(function () {
		AMCNUI.Premiere.init();
	});

})(window.jQuery);
