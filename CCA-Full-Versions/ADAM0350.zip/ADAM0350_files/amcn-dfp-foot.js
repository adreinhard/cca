/* Invoke DFP Script */

_amcn_dfp.register();
