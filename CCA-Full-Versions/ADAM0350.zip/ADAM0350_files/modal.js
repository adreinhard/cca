var AMCNUI = AMCNUI || {};

(function ($) {

	AMCNUI.Modal = AMCNUI.Modal || {
		/**
		 * Bool to store state of the modal
		 *
		 * @var bool - True if modal is open, false if closed
		 */
		isOpen: false,

		/**
		 * Modal default settings
		 *
		 * @var object - Default params
		 */
		defaultSettings: {
			width: '500px',
			height: '350px',
			classes: ''
		},

		/**
		 * Initializer. Adds modal overlay and container markup to page.
		 * Adds close click event to modal close button.
		 *
		 * @return undefined
		 */
		init: function () {
			$('body').append(
				'<div id="amcn-ui-modal-overlay"></div>' +
				'<div id="amcn-ui-modal">' +
				'<div id="amcn-ui-modal-close"></div>' +
				'<div id="amcn-ui-modal-container"></div>' +
				'</div>'
			);

			this.overlay = $('#amcn-ui-modal-overlay');
			this.modal = $('#amcn-ui-modal');

			$(document).on('click', '#amcn-ui-modal-overlay.close-enabled, #amcn-ui-modal-close', function (e) {
				AMCNUI.Modal.close();
			});
		},

		/**
		 * Renders existing template markup into modal
		 *
		 * @param id string - The CSS ID of the template element
		 * @param settings object - Settings for the modal
		 * @return undefined
		 */
		renderTemplate: function (id, settings) {
			var settings = $.extend({}, this.defaultSettings, settings);

			if ($('#' + id).length) {
				AMCNUI.Modal.open($('#' + id).html(), settings);
			}
		},

		/**
		 * Open the modal with overlay
		 *
		 * @param html string - HTML to populate in modal
		 * @param width string - Desired width of the modal
		 * @param height string - Desired height of the model
		 * @return undefined
		 */
		open: function (html, settings) {
			// close if already open
			AMCNUI.Modal.close();

			// set dimensions
			this.modal.css({
				'width': settings.width,
				'height': settings.height
			});

			// add classes
			this.modal.addClass(settings.classes);

			// insert html
			this.modal.find('#amcn-ui-modal-container').html(html);

			this.overlay.show();
			this.modal.show();
			this.isOpen = true;
		},

		/**
		 * Close the model and overlay
		 *
		 * @return undefined
		 */
		close: function () {
			if (this.isOpen) {
				//trigger 'modalClosed' event
				jQuery(document).trigger('amcn_ui.modalClosed');

				//hide modal
				this.modal.find('#amcn-ui-modal-container').empty();
				this.modal.hide();
				this.overlay.hide();
				this.isOpen = false;
			}
		}
	}

	$(window).ready(function () {
		AMCNUI.Modal.init();
	});

})(window.jQuery);