var youboraAMCNWrapper = youboraAMCNWrapper || {} ;

// register Youbora analytics module
youboraAMCNWrapper = (function() {
    this.transactionCode = '';

    // initializer for all the events
    var init = function(){
		console.log('%c <<<<<<<< youbora analytics init >>>>>>>> ', 'background-color:#ff00ff; color:#00ffff');

        var listeners = this.eventListeners();
        $pdk.controller.addEventListener('OnLoadReleaseUrl', listeners.OnLoadReleaseUrl, '*');
        $pdk.controller.addEventListener('OnReleaseStart', listeners.OnReleaseStart, '*');
    };

    var eventListeners = function() {

        var OnLoadReleaseUrl = function(response) {
            if (!youboraAMCNWrapper.disableInsantiation) {
                var title, show, season, episode, duration, guid, videoCategory, url, isLivestream = false;
                var videoData = response.data;
                var player = amcnPlatform.core.handler.getStoredPlayers()[0];
                var playerInfo = player.getConfig();
                // workaround for specific episodes which has no season/episode data from backend
                try{
                    var seasonPlusEpisode = jQuery('.season-episode').first().text().trim().split("—");
                    var spareSeason = seasonPlusEpisode[0].length ? seasonPlusEpisode[0].match(/\d+/gm)[0] : '';
                    var spareEpisode = seasonPlusEpisode[1].length ? seasonPlusEpisode[1].match(/\d+/gm)[0] : '';
                }
                catch(e){
                    //
                };
    
                // response data mapper
                for (var key in videoData) {
                    key.indexOf("title") >=0 ? title = videoData[key] :
                    key.indexOf("$show") >=0 ? show = videoData[key] :
                    (key.indexOf("$season") >=0 && /^\d+$/.test(videoData[key]))  ? season = videoData[key] :
                    (key.indexOf("$episode") >=0 && /^\d+$/.test(videoData[key]))  ? episode = videoData[key] :
                    key.indexOf("$videoCategory") >=0 ? videoCategory = videoData[key] :
                    key.indexOf("duration") >=0 ? duration = videoData[key] :
                    key.indexOf("guid") >=0 ? guid = videoData[key] :
                    key.indexOf("url") >=0 ? url = videoData[key] : "";
                }
    
                // copied from pdk-events plugin - should be rafactored
                for(var i = 0; i < videoData.categories.length; i++){
                    if(videoData.categories[i].name == 'Live Stream'){
                        isLivestream = true;
                    }
                }
    
                // YB native Logger
                youbora.Log.logLevel = youbora.Log.Level.DEBUG
                window.youboraInstance = new youbora.Plugin({
                    accountCode: playerInfo.settings.account.account_code_youbora,
                    transactionCode: youboraAMCNWrapper.transactionCode ? youboraAMCNWrapper.transactionCode : ''
                });
                
                title = title + '|' + 
                        (show || 'none') + '|' +
                        (season || _ca._defaultValues.season || spareSeason || 'none') + '|' +
                        (episode || _ca._defaultValues.episode_numeric || spareEpisode || 'none');
                youboraInstance.setOptions({
                    'content.title': title,
                    'content.duration': duration,
                    'content.isLive': isLivestream,
                    'content.resource': url,
                    'content.transactionCode': youboraAMCNWrapper.transactionCode ? youboraAMCNWrapper.transactionCode : '',
                    'extraparam.1': amcnPlatformConfig.network,
                    'extraparam.2': _ca.get_uid(),
                    'extraparam.3': guid,
                    'extraparam.4': isLivestream ? "livestream" : videoCategory,
                    'extraparam.5': jQuery.cookie(amcnPlatformConfig.network+'-tve-app_state') || ''
                });
                
                if (typeof rewritePlugin != "undefined") {
                    var adapter = new youbora.adapters.ThePlatform(rewritePlugin.controller);
                    youboraInstance.setAdapter(adapter);
                }

                youboraAMCNWrapper.disableInsantiation = true;
            }
        };

        var OnReleaseStart = function(response) {
            youboraAMCNWrapper.disableInsantiation = true;
        }

        return {
            OnLoadReleaseUrl: OnLoadReleaseUrl,
            OnReleaseStart: OnReleaseStart,
        };
    };

    return {
        init: init,
        eventListeners: eventListeners
    };
});
			