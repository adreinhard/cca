(function ($) {
	var udbCheckCookie = '_amcn_ghost.udb_check',
		firebaseConnection = false,
		fb_initialized = false
	userLevel = undefined;

	function firebaseInit() {
		if ('object' !== typeof _amcn_ghost_config) {
			return false;
		}

		firebase.initializeApp(_amcn_ghost_config);
		firebaseConnection = true;

		return true;
	}

	if (!$.cookie(udbCheckCookie)) {
		console.log('GHOST: no cookie, initializing ghost');
		// Wait for authentication status before attempting to get user Adobe data
		$(document).on('amcn.setAuthenticationStatus', function (event, isAuthenticated, errorCode) {
			if (isAuthenticated) {
				console.log('GHOST: requesting userID');
				accessEnablerAPI.getMetadata('userID');
			} else {
				console.log('GHOST: resume - no auth');
				jQuery(document).trigger('amcn.ghostAllowAutoplay');
			}
		});

		// check for user level
		$(document).on('amcn.adobe.userstate.events.v1', function (event, data) {
			if (data.hasOwnProperty('userLevel')) {
				var prefix = AmcnUDB.getChannelPrefix();

				userLevel = prefix + data.userLevel;
			}
		});

		// Wait for user data before checking if newsletter prompt should be displayed
		$(document).on('amcn.setMetadataStatus', function (event, key, args, result) {

			console.log('GHOST: setMetadataStatus', key, args, result);

			// only execute when responding ot request for userID
			if (key != 'userID') {
				return;
			}

			if (!firebaseConnection) {
				if (!firebaseInit()) {
					console.log('Firebase config not set.');
					return;
				}
			}

			//ensure firebase queries and logic run only once on page
			if (fb_initialized) {
				fb_initialized = true;
				return;
			}

			AmcnUDB.init(function () {
				console.log('GHOST: init');
				var gaId = _ca.get_uid();

				// Update with info we already have immediately
				AmcnUDB.update({
					ga_uid: gaId,
					adobe_id: result,
					mso: $.cookie(amcnPlatformConfig.network + '-v4-tve-authn'),
					user_level: userLevel
				});

				// First look for user by Adobe ID
				AmcnUDB.getByAdobeID(result, function (entity) {
					console.log('GHOST: getByAdobeID', result, entity);
					if (null === entity || null === entity.hash) {
						// If user not found or if they have no hash set then look for them by GA ID
						AmcnUDB.getByGAUID(gaId, function (entity) {
							console.log('GHOST: getByGAUID', gaId, entity);
							if (null === entity || null === entity.hash) {
								console.log('GHOST: setting signup window');

								// If user or hash still not found then render email prompt
								AMCNUI.Modal.renderTemplate('signupNewsletter', {
									width: '880px',
									'max-height': '700px',
									classes: 'newsletter-signup'
								});

								//trigger event: newsletterSignupToggled
								$(document).trigger('amcn_mvpd_auth.newsletterSignupToggled');


								var form = $('#amcn-ui-modal #newsletter-widget-form');

								// Add some validation before submission
								form.validate({
									submitHandler: function () {
										form.find('.button-wrapper input').hide();
										form.find('.button-wrapper').append('<div class="loading-icon"></div>');

										//trigger event: newsletterSignupToggled
										$(document).trigger('amcn_mvpd_auth.newsletterSubmitted');

										var userEmail = form.find('input.email').val(),
											mso = $.cookie(amcnPlatformConfig.network + '-v4-tve-authn'),
											newsletters = [];

										// Save to UDB
										AmcnUDB.update({
											email: userEmail,
											ga_uid: gaId,
											adobe_id: result,
											mso: mso,
											user_level: userLevel
										});

										// Signup for newsletter
										$.ajax({
											method: 'POST',
											url: '/api/user/v1/enqueue.sweeps',
											data: {
												email: userEmail,
												mso: mso,
												newsletters: [$('#newsletter').val()],
												leanplum_ids: [$('#leanplum_id').val()],
												url: window.location.href,
												pageTitle: document.title,
												ga_source: 'web',
												ga_campaign: 'amc_com',
												ga_medium: 'mvpd_auth',
												sweeps: 26776,
												skip_mso_check: true
											}
										}).done(function (response) {
											//hide newsletter input
											$('#amcn-ui-modal .signup-newsletter-container').hide();

											//enable close functionality on modal overlay
											$('#amcn-ui-modal-overlay').addClass('close-enabled');

											//trigger 'modalClosed' after 2 sec
											setTimeout(function () {
												AMCNUI.Modal.close();
											}, 2000);

											//show/hide success
											if (!response.success) {
												$('#amcn-ui-modal .failure').show();
											}
										});
									}
								});

							} else {
								console.log('GHOST: resume - getByGAUID empty');
								jQuery(document).trigger('amcn.ghostAllowAutoplay');
							}
						});
					} else {
						console.log('GHOST: resume - getByAdobeID empty');
						jQuery(document).trigger('amcn.ghostAllowAutoplay');
					}
				});


				// Set cookie with 1 month (30 days) expiry
				var date = new Date();
				date.setTime(date.getTime() + (30 * 24 * 60 * 60 * 1000));
				$.cookie(udbCheckCookie, true, {
					expires: date,
					path: '/'
				});
				console.log('GHOST: cookie set');
			});
		});
	} else {
		console.log('GHOST: resume - cookie present');
		jQuery(document).trigger('amcn.ghostAllowAutoplay');
	}
})(window.jQuery);