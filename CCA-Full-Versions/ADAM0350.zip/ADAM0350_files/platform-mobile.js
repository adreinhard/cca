jQuery(document).ready(function(){
	var UA = navigator.userAgent;
	allowMobileWeb = true;

	// Allow Preacher Pilot episode to play on mobile web
	if(jQuery(".amcn_video_episode._amcn_show-preacher._amcn_season-season-1").is('[class*="episode-00"], [class*="pilot"]')){
		allowMobileWeb = true;
	}

	if(amcnGUP('suppress-swap')){
		allowMobileWeb = true;
	}

	// only execute on Episode or Extras pages
	// force Android and iOS users into TVE App to watch full episodes
	if ( allowMobileWeb === false && jQuery('body').is('.single-amcn_video_episode') ) {

		if ( UA.match(/Android/i ) != null ) {
			var androidHTML =
			'<div class="mobile-intercept"> \
				<h3><a href="https://play.google.com/store/apps/details?id=com.amctve.amcfullepisodes">To view this episode, please download the <strong>AMC app</strong> on Android. Full episodes are not available for viewing via mobile browser.</a></h3> \
			</div>';

			jQuery('#video-player-modal').remove(); //remove video
			jQuery(':not(.slide-interstitial).entry-content').prepend(androidHTML);//append message

		}

		if ( UA.match(/iPhone|iPad|iPod/i) != null ) {
			var iOSHTML =
			'<div class="mobile-intercept"> \
				<h3><a href="https://itunes.apple.com/us/app/amc-latest-full-episodes-extras/id1025120568">Full episodes are currently unavailable for viewing via mobile browser on iOS. To view this episode, please download the <strong>AMC app</strong> for iPhone and iPad.</a></h3> \
			</div>';

			jQuery('#video-player-modal').remove();//remove video
			jQuery(':not(.slide-interstitial).entry-content').prepend(iOSHTML); //append message
		}

	}

	if ( allowMobileWeb === false && jQuery('body').is('.single-amcn_video_movie') ) {

		if ( UA.match(/Android/i ) != null ) {
			var androidHTML =
			'<div class="mobile-intercept"> \
				<h3><a href="https://play.google.com/store/apps/details?id=com.amctve.amcfullepisodes">Movies are currently unavailable for viewing via mobile browser. To view this movie, please download the <strong>AMC app</strong> for Android.</a></h3> \
			</div>';

			jQuery('#video-player-modal').remove();//remove video
			jQuery(':not(.slide-interstitial).entry-content').prepend(androidHTML);//append message

		}

		if ( UA.match(/iPhone|iPad|iPod/i) != null ) {
			var iOSHTML =
			'<div class="mobile-intercept"> \
				<h3><a href="https://itunes.apple.com/us/app/amc-latest-full-episodes-extras/id1025120568">Movies are currently unavailable for viewing via mobile browser on iOS. To view this movie, please download the <strong>AMC app</strong> for iPhone and iPad.</a></h3> \
			</div>';

			jQuery('#video-player-modal').remove();//remove video
			jQuery(':not(.slide-interstitial).entry-content').prepend(iOSHTML);//append message
		}

	}
    if ( UA.match(/iPhone|iPad|iPod|Android/i) != null ) {
        if(!jQuery('#wpadminbar.mobile').length) {
        	jQuery('.header-secondary').css('top','0');
        }
    }



});

function amcnGUP( name ) {
  name = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
  var regexS = "[\\?&]"+name+"=([^&#]*)";
  var regex = new RegExp( regexS );
  var results = regex.exec( window.location.href );
  if( results === null )
    return "";
  else
    return results[1];
}
