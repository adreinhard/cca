document.write(unescape("%3Cscript src='" + (document.location.protocol == "https:" ? "https://sb" : "http://b") 
+ ".scorecardresearch.com/beacon.js' %3E%3C/script%3E")); 