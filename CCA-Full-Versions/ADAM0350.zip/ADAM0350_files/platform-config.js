var amcnPlatformConfig = {
	fullEpisodeArchive: ('<p>You have no full episodes in your library. Click <a href="/full-episodes-archive">here</a> to watch full episodes now.</p>'),
	network: 'amc',
	resource_default: "AMC",
	resource_adfree: "amc_adfree"
};
