var AMC_AB_Test = {

	isActive: function(ab_campaign){
		var active = false;
		(function($){
			var now = new Date().getTime();
			if(window.console) {
				console.log('now, start_at, end_at', ab_campaign.start_at, ab_campaign.end_at);
				console.log('cookie', $.cookie(ab_campaign.cookie));
			}

			if(now > ab_campaign.start_at && now < ab_campaign.end_at) {
				if(!$.cookie(ab_campaign.cookie))
					active = true;
			}
		})(jQuery);
		return active;
	},

	init: function(){
		var my = this;

		(function($){
			$(function(){
				var pos = document.URL.indexOf("?");
				var pageURL = (pos !== -1) ? document.URL : document.URL.substring(0, pos);

				for(var i in active_ab_test) {
					var ab_campaign = active_ab_test[i];


					if((my.isActive(ab_campaign)) ) {

						//choose templates
						var rand_template = ab_campaign.templates[Math.floor(Math.random() * ab_campaign.templates.length)];

						//set cookie with template in campaign
						$.cookie(ab_campaign.cookie, rand_template, {
							// expires: ab_campaign.frequency,
							expires: 1, //set expiration of campagin for one day
							path: '/',
							domain: document.domain
						});

					}

					//set jQuery template with modifications

					var template = $.cookie(ab_campaign.cookie);

					//get ab_template content
					$template_content = ab_campaign[template];

					//append jquery modfifiers to page if campaign is running
					$('body').append('<div id="ab_template">'+$template_content+'</div>');

					//tracking
					my.tracking();

				}
			});
		})(jQuery);

	},


	tracking: function(){

		var my = this;
		(function($){
			$(function(){

				//empty tracking


			});

		})(jQuery);
	}
}

if ( active_ab_test != "" ) {
	AMC_AB_Test.init();
}
