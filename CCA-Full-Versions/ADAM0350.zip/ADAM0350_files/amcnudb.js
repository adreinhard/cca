var AmcnUDB = {
	initialized: false,
	initial_check: true,
	hash_endpoint: AmcnUDBConfig.hash_endpoint,
	channel: AmcnUDBConfig.channel,
	default_user_level: AmcnUDBConfig.default_user_level,
	callbacks: {},
	refName: {
		ENTITY: 'entity',
		EMAILHASH: 'hash',
		ADOBE_IDS: 'adobe_ids',
		GA_UIDS: 'ga_uids'
	},

	/**
	 * Search entity via email hash
	 */
	getByEmail: function(email, callback) {
		if(!AmcnUDB.initialized) {
			return false;
		}

		// nothing to look for if adobe_id is null
		if(email === null) {
			callback(null);
			return;
		}

		AmcnUDB._getEmailHash(email, function(hash) {
			firebase.database().ref(AmcnUDB.refName.EMAILHASH + '/' + hash).once('value', function(res) {
				var obj = res.val();
				if(obj != null && obj.entityId !== null) {
					AmcnUDB.getEntity(obj.entityId, false, callback);
				}
				else {
					callback(null);
				}
			});
		});
	},

	/**
	 * Search entity via AdobeID
	 */
	getByAdobeID: function(adobe_id, callback) {

		if(!AmcnUDB.initialized)
			return false;


		// nothing to look for if adobe_id is null
		if(adobe_id === null) {
			callback(null);
			return;
		}

		firebase.database().ref(AmcnUDB.refName.ADOBE_IDS + "/" + adobe_id).once('value', function(res){
			var obj = res.val();
			if(obj != null && obj.entityId !== null) {
				AmcnUDB.getEntity(obj.entityId, false, callback);
			}
			else {
				callback(null);
			}
		});
	},

	/**
     * Search entity via GA UID
	 */
	getByGAUID: function(ga_uid, callback) {

		if(!AmcnUDB.initialized)
			return false;

		// nothing to query for if ga_uid is null
		if(ga_uid === null) {
			callback(null);
			return;
		}

		firebase.database().ref(AmcnUDB.refName.GA_UIDS + "/" + ga_uid).once('value', function(res){
			var obj = res.val();
			if(obj != null && obj.entityId !== null) {
				AmcnUDB.getEntity(obj.entityId, false, callback);
			}
			else {
				callback(null);
			}
		});
	},

	/**
	 * searches for entity Id, and execute callback.
	 */
	getEntity: function(entityId, retrieveFull, callback) {

		if(!AmcnUDB.initialized)
			return false;

		if(entityId === null) {
			callback(null);
			return;
		}

		firebase.database().ref(AmcnUDB.refName.ENTITY + "/" + entityId).once('value', function(res){
			var obj = res.val();
			if(obj != null) {

				// check email exists
				firebase.database().ref(AmcnUDB.refName.EMAILHASH).orderByChild('entityId').equalTo(entityId).once('value', function(res) {
					obj[AmcnUDB.refName.EMAILHASH] = res.val();


					// if further drilling down is requested, drilldown further
					if(retrieveFull) {
						firebase.database().ref(AmcnUDB.refName.ADOBE_IDS).orderByChild('entityId').equalTo(entityId).once('value', function(res) {
							obj[AmcnUDB.refName.ADOBE_IDS] = res.val();
							firebase.database().ref(AmcnUDB.refName.GA_UIDS).orderByChild('entityId').equalTo(entityId).once('value', function(res) {
								obj[AmcnUDB.refName.GA_UIDS] = res.val();

								// create callback
								AmcnUDB._callback(entityId, obj, callback);
							});
						});
					}

					// no ga or adobe id is required
					else {
						AmcnUDB._callback(entityId, obj, callback);
					}
				});
			}
			else {
				// create callback
				AmcnUDB._callback(null, callback);
			}
		});
	},

	/**
	 * Get a prefix string based on the channel config value
	 */
	getChannelPrefix: function() {
		return AmcnUDB.channel + '_';
	},

	/**
	 * Execute Callback
	 */
	_callback: function(entityId, obj, callback) {

		if(!AmcnUDB.initialized)
			return false;

		var r = obj;
		r.entityId = entityId;
		callback(obj != null ? r : null);
	},

	/**
	 * Generate Email Hash.
	 */
	_getEmailHash: function(email, callback) {

		if(!AmcnUDB.initialized)
			return false;

		httpRequest = new XMLHttpRequest();

	    if (!httpRequest) {
	      console.log('Cannot create an XMLHTTP instance');
	      return false;
	    }

		httpRequest.onreadystatechange = function(){
			if (httpRequest.readyState === XMLHttpRequest.DONE) {
				if (200 === httpRequest.status) {
					var response = JSON.parse(httpRequest.responseText);

					if(response.success){
						hash = response.data.firebase_key;

						callback(hash);
					}
				} else {
					console.log('Error in processing email hash. Error ' + httpRequest.status);
				}
			}
		}

		httpRequest.open('POST', AmcnUDB.hash_endpoint, true);
		httpRequest.setRequestHeader('Content-Type', 'application/json');
		httpRequest.send(JSON.stringify({email: email, channel: AmcnUDB.channel}));
	},

	/**
	 * update. pass in object w/ { email: "" adobe_id: "", mso: "", ga_uid: "" }
	 */
	update: function(params, callback) {

		if(!AmcnUDB.initialized)
			return false;

		var email = 'email' in params && undefined !== params.email ? params.email : null;
		var adobe_id = 'adobe_id' in params && undefined !== params.adobe_id ? params.adobe_id : null;
		var mso = 'mso' in params && undefined !== params.mso ? params.mso : null;
		var ga_uid = 'ga_uid' in params && undefined !== params.ga_uid ? params.ga_uid : null;
		var user_level = 'user_level' in params && undefined !== params.user_level ? params.user_level : AmcnUDB.default_user_level;

		// query by email
		AmcnUDB.getByEmail(email, function(obj) {

			// found entity associated with adobe_id
			if(obj !== null) {
				var entityId = obj.entityId;
				AmcnUDB._update(entityId, email, adobe_id, mso, ga_uid, user_level, callback);
			}
			else {

				// query if adobe object exists
				AmcnUDB.getByAdobeID(adobe_id, function(obj) {

					// found entity associated with adobe_id
					if(obj !== null) {
						var entityId = obj.entityId;
						AmcnUDB._update(entityId, email, adobe_id, mso, ga_uid, user_level, callback);
					}
					else {
						// find entity assoociated with ga_uid
						AmcnUDB.getByGAUID(ga_uid, function(obj) {
							if(obj !== null) {
								var entityId = obj.entityId;
								AmcnUDB._update(entityId, email, adobe_id, mso, ga_uid, user_level, callback);
							}

							// must create new entity
							else {
								var entityId = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
									var r = Math.random()*16|0;
									var v = c == 'x' ? r : (r&0x3|0x8);
									return v.toString(16);
								});
								AmcnUDB._update(entityId, email, adobe_id, mso, ga_uid, user_level, callback);
							}

						});
					}

				});
			}

		});
	},

	/**
	 * Helper function to update the data
	 */
	_update: function(entityId, email, adobe_id, mso, ga_uid, user_level, callback) {

		if(!AmcnUDB.initialized)
			return false;

		// filtering errored values
		if(entityId === null) {
			if(window.console)
				console.log("data was not saved, due to missing entityId.");
			return;
		}
		if(ga_uid === null) {
			if(window.console)
				console.log("data was not saved, due to missing ga_uid.");
			return;
		}
		if(adobe_id !== null && mso === null) {
			if(window.console)
				console.log("data was not saved, due to missing mso related to adobeId info.");
			return;
		}
		if(email === null && adobe_id === null) {
			if(window.console)
				console.log("data was not saved, email or adobe_id must be defined.");
			return;
		}

		// create unique id for our callback
		var callbackId = [entityId, adobe_id, ga_uid].join('-');

		// store for later check and execution
		AmcnUDB.callbacks[callbackId] = {
			callback: callback !== undefined ? callback : function(){},
			checks: {
				email: false,
				adobeId: false,
				gaUid: false
			}
		};

		// update entity info
		firebase.database().ref(AmcnUDB.refName.ENTITY + '/' + entityId).set(
			{
				'updatedAt': firebase.database.ServerValue.TIMESTAMP
			},
			function(){
				// update email
				if(email !== null) {
					AmcnUDB._getEmailHash(email, function(hash){
						firebase.database().ref(AmcnUDB.refName.EMAILHASH + '/' + hash).set(
							{
								'updatedAt': firebase.database.ServerValue.TIMESTAMP,
								'entityId': entityId
							},
							function() {
								AmcnUDB.checkAndExecuteCallback(callbackId, 'email');
							}
						);
					});
				} else {
					AmcnUDB.checkAndExecuteCallback(callbackId, 'email')
				}

				// adobe id
				if(adobe_id !== null) {
					firebase.database().ref(AmcnUDB.refName.ADOBE_IDS + '/' + adobe_id).set(
						{
							'mso': mso,
							'userLevel': user_level,
							'updatedAt': firebase.database.ServerValue.TIMESTAMP,
							'entityId': entityId
						},
						function() {
							AmcnUDB.checkAndExecuteCallback(callbackId, 'adobeId');
						}
					);
				} else {
					AmcnUDB.checkAndExecuteCallback(callbackId, 'adobeId')
				}

				// store ga_uid
				if(ga_uid !== null) {
					firebase.database().ref(AmcnUDB.refName.GA_UIDS + '/' + ga_uid).set(
						{
							'updatedAt': firebase.database.ServerValue.TIMESTAMP,
							'entityId': entityId
						},
						function() {
							AmcnUDB.checkAndExecuteCallback(callbackId, 'gaUid');
						}
					);
				} else {
					AmcnUDB.checkAndExecuteCallback(callbackId, 'gaUid')
				}
			}
		);

	},

	/**
	 * Execute a callback only after a set number of checks have been met
	 */
	checkAndExecuteCallback: function(callbackId, checkKey){
		var callbackObject;

		if(!(callbackId in AmcnUDB.callbacks)){
			console.log('Callback object not found');
			return;
		}

		callbackObject = AmcnUDB.callbacks[callbackId];

		callbackObject.checks[checkKey] = true;

		for (var check in callbackObject.checks) {
		    if (callbackObject.checks.hasOwnProperty(check)) {
		        if(!callbackObject.checks[check]){
		        	return;
		        }
		    }
		}

		callbackObject.callback();
	},

	/**
	 * Initializer
	 */
	init: function(callback) {

		if(!AmcnUDB.initial_check) {
			return false;
		}
		AmcnUDB.initial_check = true;


		if(AmcnUDB.initialized) {
			callback();
		}
		else {

			firebase.auth().signInAnonymously().catch(function(error) {
			  var errorCode = error.code;
			  var errorMessage = error.message;
			});
			firebase.auth().onAuthStateChanged(function(user) {

			  if (user) {
				if(user.isAnonymous && user.uid !== null && AmcnUDB.initialized === false) {
					AmcnUDB.initialized = true;
					callback();
				}
			  } else {

			  }
			});

		}
	}
};
