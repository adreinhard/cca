var amcnPlatform = amcnPlatform || {};

function readCookie(name, c, C, i) {
	if ( 'undefined' !== typeof cookies) {
		return cookies[name];
	}

	c = document.cookie.split('; ');
	cookies = {};

	for (i = c.length - 1; i >= 0; i--) {
		C = c[i].split('=');
		cookies[C[0]] = C[1];
	}
	return cookies[name];
}
//listen for pre-flight check
jQuery(document).on("amcn.adobe.userstate.events.v1", triggerAdobeUserState);

function triggerAdobeUserState(event, response) {
	var authn_cookie = amcnPlatformConfig.network + '-v4-tve-authn';
	var app_state_cookie = amcnPlatformConfig.network + '-tve-app_state';

	//if premiere provider (only xfinity right now)
	if (readCookie(authn_cookie) === 'Comcast_SSO') {
		if (response.userLevel === 'adfree') 
			createCookie(app_state_cookie, 'premiere', 1)
		else if(response.userLevel === 'auth')
			createCookie(app_state_cookie, 'potpremiere', 1)

	} else if (readCookie(authn_cookie) !== 'Comcast_SSO' && response.userLevel === 'auth') {
		createCookie(app_state_cookie, 'auth', 1);
		
	} else if (readCookie(authn_cookie) === 'NonAuth' || readCookie(authn_cookie) == null) {
		// fire off default user
		createCookie(app_state_cookie, 'unauth', 1);
	}
};

// register premiere module
amcnPlatform.namespace('amcnPlatform.module.premiere');
amcnPlatform.module.premiere = (function(){

	var init = function(response){
		console.log('%c //////// premiere | init //////// ', 'background-color:gold; color:black');

		var publishStateCookie = amcnPlatformConfig.network + '-tve-publish_state';
		// publishState = (jQuery.cookie(publishStateCookie) != 'undefined') ? jQuery.cookie(publishStateCookie) : 'public';
		publishState = (readCookie(publishStateCookie) != 'undefined') ? readCookie(publishStateCookie) : 'public';

		var listeners = eventListeners();
		$pdk.controller.addEventListener('amcn.pdk.events.OnSetVideoValues', listeners.OnSetVideoValues, '*');
		$pdk.controller.addEventListener('amcn.pdk.events.triggerUserState', listeners.triggerUserState, '*');

		if( (typeof premiereConfig === 'undefined') || premiereConfig.premiereEnabled === false ){
			console.log('%c //////// premiere | disabled //////// ', 'background-color:gold; color:black');
			$pdk.controller.dispatchEvent('OnPremiereComplete', {type: 'premiere', set: true, players: [response.data.player.instance]}, [response.data.player.instance]);
		}
	};

	// return player instance for data usage
	var getPlayerInstance = function(instance){
		if(typeof amcnPlatformPlayers[instance] !== 'undefined'){
			return amcnPlatformPlayers[instance];
		}
		else{
			throw 'Undefined player instance ['+instance+']';
		}
	};

	var premiereOverlayShow = function(messageType){
		console.log('%c //////// premiere | show overlay //////// ', 'background-color:gold; color:black', premiereConfig);

		if(messageType == 'restricted'){
			var message = premiereConfig.message.restricted;
		}
		else if(messageType == 'pre'){
			var message = premiereConfig.message.pre;
		}
		else{
			var message = premiereConfig.message.default;
		}

		var intercept = '<div id="platform-intercept" class="restricted">' +
							'<div class="intercept-message">' +
								'<p>'+message+'</p>' +
							'</div>';
						'</div>';
		
		jQuery('.platform-container').prepend(intercept);
	};

	var eventListeners = function(){

		// asset load event listener - sets video object values for reuse
		var OnSetVideoValues = function(response){
			try{
				var player = getPlayerInstance(response.data.player.instance);
				//var playerConfig = player.getConfig();
				//var videoCustomValues = playerConfig.settings.video.details.custom;
				// var timestamp = + new Date() / 1000;
				var timestamp = Math.floor(Date.now() / 1000);
				var videoAuthState = amcnVideo.playback.auth;
				var videoCategory = amcnVideo.settings.video.details.custom.videoCategory;
				var livestream = amcnVideo.settings.video.details.isLivestream;
				var restrictedEnd = Number(amcnVideo.settings.video.details.custom.restrictedExpirationDate) / 1000;
				var restrictedStart = Number(amcnVideo.settings.video.details.custom.restrictedAvailableDate) / 1000;
				var publicEnd = Number(amcnVideo.settings.video.details.custom.publicExpirationDate) / 1000;
				var publicStart = Number(amcnVideo.settings.video.details.custom.publicAvailableDate) / 1000;


				// Triggered when there are public and restricted windows available
				if (publicStart && publicEnd && restrictedStart && restrictedEnd) {
					if (publishState == 'public' && timestamp < publicStart || timestamp > publicEnd) {
						console.log('we\'re public and outside of the public window');
						amcnPlatform.module.premiere.premiereOverlayShow('restricted');
					} else if (publishState == 'restricted' && ((timestamp < restrictedStart && timestamp < publicStart) || (timestamp > restrictedEnd && timestamp > publicEnd))) {
						console.log('were restricted and restricted start hasnt started');
						console.log('%c //////// premiere | pre restricted //////// ', 'background-color:gold; color:black');
						amcnPlatform.module.premiere.premiereOverlayShow('pre');
					} else if (!publishState && (timestamp < publicStart || timestamp > publicEnd)) {
						console.log('we\'re outside of both windows');
						amcnPlatform.module.premiere.premiereOverlayShow('restricted');
					} else if (!publishState && (isNaN(publicStart) && isNaN(publicEnd))) {
						console.log('we\'re outside of both windows');
						amcnPlatform.module.premiere.premiereOverlayShow('restricted');
					} else if ((publishState == 'public' || publishState == 'restricted') && livestream) {
						return;
					}
					// triggered when there is only a restricted window
				} else if (restrictedStart && restrictedEnd) {
					if (publishState == 'public') {
						console.log('were public and in the restricted window');
						console.log('%c //////// premiere | restricted window //////// ', 'background-color:gold; color:black');
						amcnPlatform.module.premiere.premiereOverlayShow('restricted');
					} else if (restrictedStart == '' && restrictedEnd == '' && publishState == 'restricted' && livestream) {
						return;
					} else if (publishState == 'restricted' && (timestamp < restrictedStart || timestamp > restrictedEnd)) {
						console.log('were restricted and restricted start hasnt started');
						console.log('%c //////// premiere | pre restricted //////// ', 'background-color:gold; color:black');
						amcnPlatform.module.premiere.premiereOverlayShow('pre');
					} else if (!publishState && (timestamp < !isNaN(restrictedStart) || timestamp > !isNaN(restrictedEnd))) {
						console.log('we\'re unauth and this user is outside of the restricted window');
						amcnPlatform.module.premiere.premiereOverlayShow('restricted');
					} else if (videoAuthState && videoCategory == 'Shortform' && publishState == 'restricted' && restrictedStart == '' && restrictedEnd == '') {
						return;
					} else if (videoAuthState && videoCategory == 'Shortform' && publishState == 'restricted' && timestamp > restrictedStart && restrictedEnd == '') {
						return;
					}
					// triggered when there is only a public window
				} else if (publicStart && publicEnd) {
					if (publishState == 'public' && (timestamp < publicStart || timestamp > publicEnd)) {
						console.log('we\'re public and outside of the public window');
						amcnPlatform.module.premiere.premiereOverlayShow('restricted');
					} else if (publishState == 'restricted' && (timestamp < publicStart || timestamp > publicEnd)) {
						console.log('were restricted and restricted start hasnt started');
						console.log('%c //////// premiere | pre restricted //////// ', 'background-color:gold; color:black');
						amcnPlatform.module.premiere.premiereOverlayShow('restricted');
					}
					// this will change in the future to accommodate additional auth windows
				} else if (!videoAuthState || videoCategory == 'Shortform') {
					return;
				} else if (!publishState && livestream) {
					return;
				}




			}
			catch(e){
				console.log('%c AMCP ERROR (OnMediaPlaying): ', e, '', response.data.player.instance);
			}
		};

		var triggerUserState = function(response){
			console.log('%c //////// premiere | trigger user stage //////// ', 'background-color:gold; color:black', response);
		};

		return {
			OnSetVideoValues: OnSetVideoValues,
			triggerUserState: triggerUserState
		};
	};
	
	return {
		init: init,
		premiereOverlayShow: premiereOverlayShow,
 	};
}());

// register premiere module, with init method executed
amcnPlatform.core.handler.addModule(amcnPlatform.module.premiere.init);