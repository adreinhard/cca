
var UA = navigator.userAgent;
var app_type;
var banner_cookie = getCookie('app-banner');
var link_iOS = 'https://itunes.apple.com/us/app/amc-latest-full-episodes-extras/id1025120568';
var link_android = 'https://play.google.com/store/apps/details?id=com.amctve.amcfullepisodes';
var link_windows = 'https://www.microsoft.com/en-us/store/apps/amc/9nblggh1r5rn';

function getCookie(name){
	var parse = new RegExp(name + "=([^;]+)");
	var cookie_value = ( parse.exec(document.cookie) );
	return (cookie_value != null) ? unescape(cookie_value[1]) : null;
}

jQuery(document).ready(function(){
	// Kindle
	if (UA.match(/Kindle|Silk|KFAPW|KFARWI|KFASWI|KFFOWI|KFJW|KFMEWI|KFOT|KFSAW|KFSOWI|KFTBW|KFTHW|KFTT|WFFOWI/i) != null){
		app_type = 'kindle';
		jQuery(".banner-launch a").attr("href", "" );
	}
	// Windows 8 + Explicitly NOT Windows 7 + Touch events
	else if ( ( UA.match(/Windows NT 6./i) != null && UA.match(/Windows NT 6.1/i) == null ) && ( UA.match(/Touch/i) != null || UA.match(/ARM/i) != null ) ) {
		app_type = 'windows';
		jQuery(".banner-launch a").attr("href", link_windows );
	}
	// iOS devices + Chrome
	else if( ( UA.match(/iPhone|iPad|iPod/i) != null ) && (UA.match(/CriOS/i) != null ) ) {
		app_type = 'iOS';
		jQuery( ".banner-launch a").attr("href", link_iOS );
	}
	// Android
	else if (UA.match(/Android/i) != null) {
		app_type = 'android';
		jQuery(".banner-launch a").attr("href", link_android );
	}
	console.log('ua: ' + UA);
	if( ( app_type == 'iOS' || app_type == 'android' || app_type == 'windows' ) && (banner_cookie != 'dismissed' ) && app_type != 'kindle' ) {
		jQuery("#amcn-app-banner").delay(3000).queue(function(){
			jQuery(this).addClass("animate").dequeue();
		});
	}

	jQuery(".banner-close").click(function(){
		jQuery.cookie("app-banner", 'dismissed');
		jQuery("#amcn-app-banner").removeClass("animate");
	});
});