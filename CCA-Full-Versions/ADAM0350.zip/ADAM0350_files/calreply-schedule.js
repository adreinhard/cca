(function($){

	$(document).bind('amcn_schedule_content_added', function(event, scheduleContent){

		// first make sure that we have our calreply localized data
		if(typeof _amcn_calreply_data === 'object'){
			// grab each schedule item element	
			var scheduleItems = $(scheduleContent).find('.single-schedule-item-container');

			$.each(scheduleItems, function(k, v){
				var ele = $(v),
					showTitle = ele.find('.ssi-title-text').html();

				// check this schedule item if it's title matches one of our show titles in our localized data
				if(_amcn_calreply_data.meta.hasOwnProperty(showTitle)){
					var calreplyMeta = _amcn_calreply_data.meta[showTitle],
						calreplySettings = _amcn_calreply_data.settings,
						queryParams = {
							subscriberid: _ca.get_uid()
						};

					// loop through out campaign param strings and do any replacements for variable strings
					$.each(calreplySettings['campaign_params'], function(k, v){
						// replace '{show-name}' with the Careply name for the show
						queryParams[k] = v.replace('{show-name}', calreplyMeta.name);
					});

					// relatively position second parent element for link mobile view, and then append the link HTML
					ele.find('.ssi-detail, .prem-detail').css('position', 'relative').append(
						'<div class="calreply-link-schedule">'
							+ '<a class="desktop" data-calreply-name = "' + calreplyMeta.name + '" href="//' + _amcn_calreply_data.calreply_base_url + '/' + calreplyMeta.name + '/embed/?' + $.param(queryParams) + '" data-popup="lightbox" data-type="custombutton" data-calreply-binding="true">'
								+ '<span class="calreply-remind-me-icon"></span>'
								+ '<span class="remind-me-label">Remind Me</span>'
							+ '</a>'
							+ '<a class="mobile" data-calreply-name = "' + calreplyMeta.name + '" href="//' + _amcn_calreply_data.calreply_base_url + '/' + calreplyMeta.name + '?' + $.param(queryParams) + '">'
								+ '<span class="calreply-remind-me-icon"></span>'
							+ '</a>'
						+ '</div>'
					);
				}
			});

			// analytics tracking
			$('.calreply-link-schedule a').click(function(e){
				_ca.trackEvent2({
					'category': 'schedule_page',
					'action': $(this).data('calreply-name'),
					'label': 'click_calreply'
				});		
			});
		}

	});

})(window.jQuery);