// set a date based on the service timestamp
function liveTime(res){
	livestreamServiceDate = new Date(res.data.timestamp * 1000);

	// run the initialization of the schedule based on the service time 
	livestream(livestreamFeed, livestreamServiceDate);
	lsPageSchedule(livestreamFeed, livestreamServiceDate);

	// check for updates every 15 seconds
	setInterval(function(){
		// increment the time by 15
		livestreamServiceDate = new Date(livestreamServiceDate.getTime()+15000);
		console.log(livestreamServiceDate);
		livestream(livestreamFeed, livestreamServiceDate);
		lsPageSchedule(livestreamFeed, livestreamServiceDate);
	}, 15000);
}

// stream - schedule functions
function livestream(livestreamFeed, livestreamServiceDate){

	var livestreamParse = JSON.parse(livestreamFeed);
	var headerItem, currentDate, currentTime, currentIndex;
		
	// set date value from the service returned date
	currentDate = livestreamServiceDate;
	currentTime = currentDate.getTime();

	// check for diffs before updating
	if(currentTime > parseInt(jQuery('.header-secondary').find('.livestream-container').attr('data-item-expires'))){
		// iterate through all items in schedule
		jQuery.each(livestreamParse, function(index){
			headerItem = this;

			// check for item that starts before the current time, and ends after (this is the current item)
			if(currentTime > headerItem.start_time && currentTime < headerItem.end_time){
				updateLiveStreamHeader(headerItem);
				currentIndex = index;
			}
		});
		
	} else{
		console.log('not updating');
	}

}

// updates html for schedule item
function updateLiveStreamHeader(headerItem){
	var localStart, localTZ, localStartHour, localStartMinutes, localStartHourOutput;

	// update the expiration time for this content
	jQuery('.livestream-container').attr('data-item-expires', headerItem.end_time);

	var liveTitle;

	if(headerItem.genre == 'consumer'){
		liveTitle = 'Paid Programming';
	} else {
		liveTitle = headerItem.title;
	}

	// replace each line individually - using this in multiple contexts
	jQuery('.livestream-container').find('#ls-title').html(liveTitle);
	jQuery('.livestream-container').find('#ls-episode').html(headerItem.episode_title);

}