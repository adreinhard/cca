(function($){

	$(document).ready(function(){
		var calreplyLinks = $('.calreply-link a');

		if(calreplyLinks.length){
			// add ga-uid to each Calreply link
			$.each(calreplyLinks, function(k, v){
				var currentLink = $(v).attr('href');

				$(v).attr('href', currentLink + '&subscriberid=' + _ca.get_uid());
			});

			// analytics tracking
			calreplyLinks.click(function(e){
				_ca.trackEvent2({
					'category': 'show_page',
					'action': 'calreply_button',
					'label': 'click_calreply'
				});		
			});			
		}
	});

})(window.jQuery);