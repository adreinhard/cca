/**
 * Pre-Gold: Events for AMCN Ghost
 */

(function ($) {
  let searchQuery = '';
  $(document).on('input', $('#janrainModal #provider-search'), function () {
    searchQuery = $('#janrainModal #provider-search').val();
  });

  /* Click Event: MVPD Sign In link in the header */
  $(document).on('click', '.amcn-login-panel a.login', function () {
    _ca.trackEvent2({
      'category': 'mvpd_auth',
      'action': 'prompt_login',
      'label': 'nav:signin'
    });

    //alert('sigin clicked');

    //add parameter to URL for exiting tracking:
    addParam('mvpd-modal');
  });

  /* Click Event: MVPD Sign In play button in the video player */
  $(document).on('click', '.platform-container .login', function () {
    _ca.trackEvent2({
      'category': 'mvpd_auth',
      'action': 'prompt_login',
      'label': 'video:playbutton'
    });

    //alert('playbutton clicked');

    //add parameter to URL for exiting tracking:
    addParam('mvpd-modal');
  });

  /* Click Event: MVPD Picker - MSO clicked (featured) */
  $(document).on('click', '#promoted-provider-wrapper .mvpd_option', function () {
    _ca.trackEvent2({
      'category': 'mvpd_auth',
      'action': 'select_mvpd',
      'label': 'mvpd_prompt',
      'cable_provider': $(this).data('mvpd-shortname'),
      'search_query': 'not_applicable'
    });
    //parameter modification to URL for exiting tracking:
    removeParam();
  });


  /* Click Event: MVPD Picker - MSO clicked (list) */
  $(document).on('click', '#provider-list-container .mvpd_option', function () {
    _ca.trackEvent2({
      'category': 'mvpd_auth',
      'action': 'select_mvpd',
      'label': 'mvpd_prompt',
      'cable_provider': $(this).data('mvpd-shortname'),
      'search_query': searchQuery
    });
    //parameter modification to URL for exiting tracking:
    removeParam();
  });


  /* Click Event: MVPD Picker - Show all MVPDs clicked */
  $(document).on('click', '#provider-wrapper .see-more-providers', function () {
    _ca.trackEvent2({
      'category': 'mvpd_auth',
      'action': 'show_all_mvpds',
      'label': 'mvpd_prompt'
    });

    //alert('show all mvpdds clicked');
  });

  /* Click Event: MVPD Picker - Click on Need Help? link */
  $(document).on('click', '#mvpd-help', function () {
    _ca.trackEvent2({
      'category': 'mvpd_auth',
      'action': 'more_info',
      'label': 'mvpd_prompt',
      'search_query': searchQuery
    });
  });

  /* Click Event: MVPD Picker - Modal close button clicked */
  $(document).on('click', '.mvpd-auth .janrain_modal_closebutton', function () {
    _ca.trackEvent2({
      'category': 'mvpd_auth',
      'action': 'exit',
      'label': 'mvpd_prompt',
      'search_query': searchQuery
    });

    //alert('modal closed');

    //parameter modification to URL for exiting tracking:
    removeParam();
  });

  /* Triggered Event: Email Signup Toggled */
  $(document).on('amcn_mvpd_auth.newsletterSignupToggled', function () {

    _ca.trackEvent2({
      'category': 'mvpd_auth',
      'action': 'authenticated',
      'label': 'newsletter_signup',
      'cable_provider': $.cookie(amcnPlatformConfig.network + '-v4-tve-authn')
    });

    //alert($.cookie('amc-v4-tve-authn'));

    //add parameter to URL for exiting tracking:
    addParam('newsletter-signup-modal');

  });


  /* Triggered Event: Newsletter Submitted */
  $(document).on('amcn_mvpd_auth.newsletterSubmitted', function () {

    _ca.trackEvent2({
      'category': 'mvpd_auth',
      'action': 'email_entered',
      'label': 'newsletter_signup'
    });

    //alert('email entered');

    //parameter modification to URL for exiting tracking:
    removeParam();
    addParam('email-entered-thank-you-modal');


  });


  /* Click Event: Newsletter Modal / Thanks Modal Closed */
  $(document).on('amcn_ui.modalClosed', function () {

    _ca.trackEvent2({
      'category': 'mvpd_auth',
      'action': 'exit',
      'label': 'newsletter_signup'
    });

    //alert('newsletter closed');

    //parameter modification to URL for exiting tracking:
    removeParam();

    console.log('GHOST: resume - modal close');
    jQuery(document).trigger('amcn.ghostAllowAutoplay');

  });



  /* Add param(s) to the URL via pushState, and send pageView event to GA */
  function addParam(param, value) {

    value = value || true;
    var loc = location.href;

    loc += loc.indexOf("?") === -1 ? "?" : "&";


    //if param isn't already in url, add it
    if (loc.indexOf(param) == -1) {
      var url = loc + param + "=" + value;

      if (window.history.replaceState) {
        //prevents browser from storing history with each change:
        window.history.replaceState({}, null, url);
      }
    }



    //send pageView event
    _ca.trackPageView({
      'page': url
    });

  }


  /* Remove any tracking params in URL via pushstate */
  function removeParam() {

    var loc = location.href;
    var url = loc.split("?")[0];

    if (window.history.replaceState) {
      //prevents browser from storing history with each change:
      window.history.replaceState({}, null, url);
    }
  }




})(window.jQuery);