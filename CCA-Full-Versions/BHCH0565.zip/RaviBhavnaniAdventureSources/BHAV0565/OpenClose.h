// OpenClose.h : Handler for opening/closing objects
//

#ifndef _OpenClose_h_
#define _OpenClose_h_

#include "AdvGlobals.h"

void openProc
  (AdvGlobalContext&  gc);

void closeProc
  (AdvGlobalContext&  gc);

#endif