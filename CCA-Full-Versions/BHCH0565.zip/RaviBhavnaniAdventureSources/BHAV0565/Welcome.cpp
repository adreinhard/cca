// Welcome.cpp : Welcome function
//

#include "stdafx.h"

#include "AdvMain.h"
#include "AdvIO.h"

void welcome
  (AdvGlobalContext& gc)   // global context
//
//  Welcomes the adventurer
//
{
  // Welcome adventurer and offer instructions
  sayMessage (gc, logon);
  if (yes (gc, hithere))
     sayMessage (gc, intro);
  else
     sayMessage (gc, ok);

  // Describe the starting location
  sayMessage (gc, blank);
}
