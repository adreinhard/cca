// Travel.h : Handler for movement commands
//

#ifndef _Travel_h_
#define _Travel_h_

#include "AdvGlobals.h"

void climbProc
  (AdvGlobalContext&  gc);

void jumpProc
  (AdvGlobalContext&  gc);

void plunge
  (AdvGlobalContext&  gc);

void rideProc
  (AdvGlobalContext&  gc);

void swimProc
  (AdvGlobalContext&  gc);

void travel
  (AdvGlobalContext&  gc);

#endif