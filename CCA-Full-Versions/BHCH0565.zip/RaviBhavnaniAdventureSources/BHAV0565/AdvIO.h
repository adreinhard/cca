// AdvIO.h : I/O functions
//

#ifndef _AdvIO_h_
#define _AdvIO_h_

#include "AdvGlobals.h"

void describeObject
  (AdvGlobalContext&  gc,
   long               nObject,
   long               nState);

void describeObjectInven
  (AdvGlobalContext&  gc,
   long               nObject);

void describePlace
  (AdvGlobalContext&  gc,
   long               nPlace,
   bool               bLong);

void displayError
  (long   nErrorCode,
   char*  szArg1,
   char*  szArg2,
   char*  szArg3);

void getCommand
  (AdvGlobalContext&  gc);

void sayMessage
  (AdvGlobalContext&  gc,
   long               nMessage);

void sayMessageText
  (AdvGlobalContext&  gc,
   long               nMessage,
   char*              pText);

void sayMessageValue
  (AdvGlobalContext&  gc,
   long               nMessage,
   long               nValue);

void sayMessageWord
  (AdvGlobalContext&  gc,
   long               nMessage,
   long               nWord);

bool yes
  (AdvGlobalContext&  gc,
   long               nMessage);

#endif