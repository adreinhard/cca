// Throw.h : Handler for various throw actions
//

#ifndef _Throw_h_
#define _Throw_h_

#include "AdvGlobals.h"

void throwWeapon
  (AdvGlobalContext&  gc);

void throwFood
  (AdvGlobalContext&  gc);

void throwTeeth
  (AdvGlobalContext&  gc);

void breakVial
  (AdvGlobalContext&  gc);

void dropLiquid
  (AdvGlobalContext&  gc);

void dropCage
  (AdvGlobalContext&  gc);

void upChuck
  (AdvGlobalContext&  gc);

#endif