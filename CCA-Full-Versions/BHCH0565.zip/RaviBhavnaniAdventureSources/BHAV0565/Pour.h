// Pour.h : Handler for pouring action
//

#ifndef _Pour_h_
#define _Pour_h_

#include "AdvGlobals.h"

void pourProc
  (AdvGlobalContext&  gc);

#endif