// Drop.h : Handler for dropping various objects
//

#ifndef _Drop_h_
#define _Drop_h_

#include "AdvGlobals.h"

void dropProc
  (AdvGlobalContext&  gc);

#endif