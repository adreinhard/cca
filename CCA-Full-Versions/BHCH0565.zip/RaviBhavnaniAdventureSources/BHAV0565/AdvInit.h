// AdvInit.h : Initialization functions
//

#ifndef _AdvInit_h_
#define _AdvInit_h_

#include "AdvGlobals.h"

void cleanupAndExit
  (AdvGlobalContext&  gc);

bool init
  (AdvGlobalContext&  gc,
   char*              szExeFilespec);

#endif