// AdvUtil.h : Utility functions
//

#ifndef _AdvUtil_h_
#define _AdvUtil_h_

#include "AdvGlobals.h"

bool chance
  (long nProbability);

void getScore
  (AdvGlobalContext& gc);

long random
  (long nLimit);

#endif