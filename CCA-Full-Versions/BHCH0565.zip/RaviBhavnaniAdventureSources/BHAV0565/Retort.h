// Retort.h : Handler for obscenities
//

#ifndef _Retort_h_
#define _Retort_h_

#include "AdvGlobals.h"

void retort
  (AdvGlobalContext&  gc);

#endif