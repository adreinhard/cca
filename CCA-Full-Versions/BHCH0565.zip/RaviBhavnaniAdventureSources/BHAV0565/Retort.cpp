// Retort.cpp : Handler for obscenities
//

#include "stdafx.h"

#include "AdvMain.h"
#include "AdvIO.h"
#include "Retort.h"

void retort
  (AdvGlobalContext& gc)   // global context
//
//  Handler for obscenities
//
{
  // Cycle thru retorts
  gc.m_nRetort++;
  if (gc.m_nRetort == MAXRETORT)
     gc.m_nRetort = 1;

  // Say retort
  if (gc.m_nRetort == 1)
     sayMessage (gc, watchit);
  else
     sayMessage (gc, retort1 + gc.m_nRetort - 1);
}
