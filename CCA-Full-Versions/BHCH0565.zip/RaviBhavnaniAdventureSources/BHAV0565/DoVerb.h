// DoVerb.h : Handler for general actions
//

#ifndef _DoVerb_h_
#define _DoVerb_h_

#include "AdvGlobals.h"

void doVerb
  (AdvGlobalContext&  gc);

void lookProc
  (AdvGlobalContext& gc);

void mistProc
  (AdvGlobalContext& gc);

void sillyProc
  (AdvGlobalContext& gc);

#endif