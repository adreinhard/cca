// Encode.h : Encoding function for datafiles.
//

#ifndef _encode_h_
#define _encode_h_

#include "stdafx.h"

#define MAX_ENCODER_LINE_LENGTH   255
#define ENCODER_KEY               1963

void createEncoderPattern
  (long   nSeed,
   char*  szCharSet,
   char*  szPattern);

void encodeLine
  (bool   bEncode,
   char*  szSourceCharSet,
   char*  szPatternCharSet,
   char*  szLine);

#endif