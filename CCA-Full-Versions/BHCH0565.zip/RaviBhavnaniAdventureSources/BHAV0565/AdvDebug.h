// AdvDebug.h : debugger
//

#ifndef _AdvDebug_h_
#define _AdvDebug_h_

#include "AdvGlobals.h"

void advDebug
  (AdvGlobalContext& gc);

#endif