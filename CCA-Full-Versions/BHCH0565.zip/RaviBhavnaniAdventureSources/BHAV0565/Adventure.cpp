// Adventure.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include "AdvDef.h"
#include "AdvGlobals.h"
#include "AdvInit.h"
#include "AdvIO.h"
#include "AdvMain.h"

// Global variables
AdvGlobalContext  gContext;

int main (int argc, char* argv[])
{
  // Initialize game - return if unable
  if (!init (gContext, argv[0]))
     {
       cleanupAndExit (gContext);
       return (0);
     }

  // Main loop
  welcome (gContext);
  do
  {
    main0 (gContext);
    if (gContext.m_bMoved)
       main1 (gContext);
    if (!gContext.m_bJustDied)
       main2 (gContext);
  }
  forever;

  // Free memory and return
  cleanupAndExit (gContext);
	return 0;
}
