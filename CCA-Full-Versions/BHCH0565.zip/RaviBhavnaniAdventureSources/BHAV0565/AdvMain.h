// AdvMain.h : Mainline functions
//

#ifndef _AdvMain_h_
#define _AdvMain_h_

#include "AdvGlobals.h"

void coroner
  (AdvGlobalContext&  gc);

void finis
  (AdvGlobalContext&  gc);

void hintLogic
  (AdvGlobalContext&  gc);

void main0
  (AdvGlobalContext&  gc);

void main1
  (AdvGlobalContext&  gc);

void main2
  (AdvGlobalContext&  gc);

void phog
  (AdvGlobalContext&  gc);

void splatter
  (AdvGlobalContext&  gc);

void welcome
  (AdvGlobalContext&  gc);

#endif