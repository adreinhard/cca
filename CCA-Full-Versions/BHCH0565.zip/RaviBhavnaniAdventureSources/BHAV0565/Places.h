/*
 *	PLACES.H - Place #defines for Collosal Cave Adventure.
 *	(C) 1986 Ravi Bhavnani
 *	All rights reserved
 *
 *	YLEM AND LIMBO (LOCATIONS 0, 262) ARE SPECIAL LOCATIONS. YLEM
 *	IS A CACHE FOR THINGS THAT ARE KILLED, DESTROYED, ETC. LIMBO IS
 *	THE STARTING LOCATION FOR MANY OBJECTS.
 *
 *	BROKEN VASES, KILLED DRAGONS, ETC. END UP IN YLEM. THE DWARVES,
 *	PIRATE, BLOB, ETC. START OUT IN LIMBO AND ARE BROUGHT INTO THE
 *	APPROPRIATE ROOM AT THE APPROPRIATE TIME.
 */

#ifndef _Places_h_
#define _Places_h_

#define inhand			-1
#define ylem			0
#define road			1
#define hill			2
#define building		3
#define valley			4
#define forest			5
#define forest2			6
#define slit			7
#define depression		8
#define incave			9
#define cobbles			10
#define debris			11
#define canyon			12
#define birdchamber		13
#define pit			14
#define mists			15
#define eastoffissur		16
#define westoffissur		17
#define goldroom		18
#define mtking			19
#define wend2pit		20
#define eend2pit		21
#define eastpit			22
#define westpit			23
#define lownspassage		24
#define southside		25
#define westside		26
#define y2			27
#define jumble			28
#define window			29
#define window2			30
#define dirty			31
#define brink			32
#define streampit		33
#define dusty			34
#define wendmists		35
#define mazea_1			36
#define mazea_2			37
#define mazea_3			38
#define mazea_4			39
#define mazea_5			40
#define mazea_6			41
#define mazea_7			42
#define mazea_8			43
#define mazea_9			44
#define mazea_10		45
#define mazea_11		46
#define mazea_12		47
#define mazea_13		48
#define mazea_14		49
#define mazea_15		50
#define mazea_16_pit		51
#define mazea_17		52
#define mazea_18		53
#define mazea_19		54
#define mazea_20		55
#define mazea_21		56
#define mazea_22		57
#define mazea_23		58
#define mazea_24		59
#define mazea_25		60
#define mazea_26		61
#define longhalleast		62
#define longhallwest		63
#define crossover		64
#define deadend1		65
#define complex			66
#define bedquilt		67
#define swiss			68
#define slab			69
#define secretnscyn		70
#define secretnspas		71
#define secretjunction		72
#define low			73
#define deadend2		74
#define secretew_tite		75
#define nscanyonwide		76
#define tighterstill		77
#define tallewcnyn		78
#define deadend3		79
#define narrowcorrid		80
#define incline			81
#define giant			82
#define immensenspass		83
#define cavern			84
#define soft			85
#define oriental		86
#define misty			87
#define alcove			88
#define plover			89
#define dark			90
#define arched			91
#define shell			92
#define raggedcorrid		93
#define culdesac		94
#define anteroom		95
#define wittsend		96
#define mirrorcnyn		97
#define stalact			98
#define reservoir		99
#define reservoir_n		100
#define warm			101
#define balcony			102
#define fake_slit		103
#define cylinderical		104
#define treasureroom		105
#define swofchasm		106
#define neofchasm		107
#define sloping			108
#define secretcynne1		109
#define secretcynne2		110
#define corridor		111
#define fork			112
#define warmjunction		113
#define breathtaker		114
#define faces			115
#define by_figure		116
#define plain_1			117
#define plain_2			118
#define plain_3			119
#define nondescript		120
#define pentagram		121
#define chimney			122
#define tube			123
#define tube_slide		124
#define basque_1		125
#define basque_2		126
#define basque_fork		127
#define on_steps		128
#define steps_exit		129
#define storage			130
#define fake_y2			131
#define fake_jumble		132
#define catacombs_1		133
#define catacombs_2		134
#define catacombs_3		135
#define catacombs_4		136
#define catacombs_5		137
#define catacombs_6		138
#define catacombs_7		139
#define catacombs_8		140
#define catacombs_9		141
#define catacombs_10		142
#define catacombs_11		143
#define catacombs_12		144
#define catacombs_13		145
#define catacombs_14		146
#define catacombs_15		147
#define catacombs_16		148
#define catacombs_17		149
#define catacombs_18		150
#define catacombs_19		151
#define mazed_107		152
#define mazed_131		153
#define mazed_132		154
#define mazed_133		155
#define mazed_134		156
#define mazed_135		157
#define mazed_136		158
#define mazed_137		159
#define mazed_138		160
#define mazed_139		161
#define mazed_140		162
#define audience		163
#define audience_e		164
#define banshee_1		165
#define golden			166
#define arabesque		167
#define translucent		168
#define boulders		169
#define limestone		170
#define barren			171
#define bearhere		172
#define sandstone		173
#define morion			174
#define vault			175
#define peelgrunt		176
#define insafe			177
#define corrid_1		178
#define corrid_2		179
#define tool			180
#define corrid_3		181
#define cubicle			182
#define spherical		183
#define tunnel_1		184
#define glassy			185
#define lair			186
#define brink_1			187
#define brink_2			188
#define ice			189
#define slide			190
#define icecave_1		191
#define icecave_2		192
#define icecave_3		193
#define icecave_4		194
#define icecave_5		195
#define icecave_6		196
#define icecave_7		197
#define icecave_8		198
#define icecave_9		199
#define icecave_10		200
#define icecave_11		201
#define icecave_12		202
#define icecave_13		203
#define icecave_14		204
#define icecave_15		205
#define icecave_16		206
#define icecave_17		207
#define icecave_18		208
#define icecave_19		209
#define icecave_20		210
#define icecave_21		211
#define icecave_22		212
#define icecave_23		213
#define icecave_24		214
#define icecave_25		215
#define icecave_26		216
#define icecave_27		217
#define icecave_28		218
#define icecave_29		219
#define icecave_30		220
#define brink_3			221
#define crack_1			222
#define crack_2			223
#define crack_3			224
#define crack_4			225
#define arch_cor_1		226
#define arch_cor_2		227
#define arch_fork		228
#define jonah			229
#define in_jonah		230
#define fourier			231
#define shelf			232
#define beach			233
#define platform		234

/*
 *	THESE ARE "AFTERTHOUGHT" AND NEW LOCATIONS.  LIMBO IS THE LAST LOC
 *	NEEDS TO REDEFINED IF MORE PLACES ARE ADDED.
 */

#define mazed_112		235
#define icecave_31		236
#define icecave_32		237
#define icecave_33		238
#define icecave_34		239
#define icecave_35		240
#define icecave_36		241

/*
 *	THESE ARE EXTENSIONS TO THE 550 POINT VERSION. (RAB)
 */

#define nearstove		250
#define belowtrap		251
#define emergency		252
#define southend		253
#define pnjunction		254
#define pcorrid			255
#define mirrorent1		256
#define ncorrid			257
#define nslope			258
#define mirrorroom		259
#define mirrorent2		260
#define pathway			261

/*
 *	THESE ARE EXTENSIONS TO THE 550 POINT VERSION. (MC)
 */

#define hill_extended   300
#define hayfield        301

#define limbo           302

#define MAXPLACES	            310	    // number of locations

#endif