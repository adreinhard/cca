// Magician.h : Handlers for magic words
//

#ifndef _Magician_h_
#define _Magician_h_

#include "AdvGlobals.h"

void magician
  (AdvGlobalContext&  gc);

void magician2
  (AdvGlobalContext&  gc);

#endif