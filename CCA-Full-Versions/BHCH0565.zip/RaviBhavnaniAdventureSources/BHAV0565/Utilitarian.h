// Utilitarian.h : Handler for utility actions
//

#ifndef _Utilitarian_h_
#define _Utilitarian_h_

#include "AdvGlobals.h"

void utilitarian
  (AdvGlobalContext&  gc);

void sayProc
  (AdvGlobalContext&  gc);

#endif