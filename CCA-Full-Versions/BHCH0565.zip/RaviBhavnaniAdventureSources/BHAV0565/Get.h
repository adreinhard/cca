// Get.h : Handler for getting various objects
//

#ifndef _Get_h_
#define _Get_h_

#include "AdvGlobals.h"

void getProc
  (AdvGlobalContext&  gc);

#endif