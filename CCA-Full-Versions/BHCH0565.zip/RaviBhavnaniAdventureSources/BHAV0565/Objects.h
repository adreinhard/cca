/*
 *      OBJECTS.H - object #defines for Collosal Cave Adventure
 *      (C) 1988 Ravi Bhavnani
 *      All rights reserved
 *
 *	Objects
 *	  all		 0
 *	  treasures	 1 - 27
 *	  mortals	50 - 66
 *	  sundries	80 - 149
 */

#ifndef _Objects_h_
#define _Objects_h_

#define MINOBJECTS	1

#define all		0

/* TREASURES */

#define MINTREASURES	1

#define gold		1
#define diamonds	2
#define silver		3
#define jewelry		4
#define coins		5
#define chest		6
#define eggs		7
#define trident		8
#define vase		9
#define emerald		10
#define pyramid		11
#define pearl		12
#define rug		13
#define spices		14
#define chain		15
#define casket		16
#define sculpture	17
#define bracelet	18
#define ring		19
#define spyglass	20
#define bag		21
#define helmet		22
#define crown		23
#define sceptre		24
#define yacht		25
#define beads		26
#define plate		27

#define MAXTREASURES	27

/* MORTALS */

#define MINMORTALS	50

#define turtle		50
#define troll		51
#define troll2		52
#define dwarf		53
#define dragon		54
#define snake		55
#define blob		56
#define bear		57
#define clam		58
#define oyster		59
#define ogre		60
#define bird		61
#define djinn		62
#define goblins		63
#define basilisk	64
#define gong		65
#define pirate		66

#define MAXMORTALS	66

/* SUNDRY ITEMS */

#define MINSUNDRIES	80

#define keys		80
#define lamp		81
#define grate		82
#define cage		83
#define rod		84
#define steps		85
#define door		86
#define pillow		87
#define fissure		88
#define wheatstone	89
#define tablet		90
#define magazines	91
#define bottle		92
#define plant		93
#define plant2		94
#define stalactite	95
#define shadow		96
#define drawing		97
#define chasm		98
#define volcano		99
#define machine		100
#define carpet		101
#define dinghy		102
#define vial		103
#define safe		104
#define quicksand	105
#define slime		106
#define sword		107
#define throne		108
#define skeleton	109
#define statue		110
#define fog		111
#define glow		112
#define flask		113
#define unused1		114
#define teeth		115
#define shards		116
#define dynamite	117
#define knife		118
#define water		119
#define oil		120
#define axe		121
#define mirror		122
#define message		123
#define batteries	124
#define food		125
#define mushroom	126
#define tree		127
#define _pentagram	128
#define treasure	129

#define stove		130	/* EXTENSION OF 550 POINT VERSION (RAB) */
#define scroll		131
#define trapdoor	132
#define mirror2		133
#define shovel		134
#define sign		135

#define needle		140	/* EXTENSION OF 550 POINT VERSION (MC) */

#define MAXSUNDRIES	140

#define MAXOBJECTS	150

#endif