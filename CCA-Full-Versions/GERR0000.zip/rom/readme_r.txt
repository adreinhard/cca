Turn Word Wrap ON if you're using Notepad.


======
Alice.bin is the BASIC ROM image for the Ordinateur Alice.  VMC-10 contains a copy of this built-in.

Hackedmc10.bin is the BASIC ROM image, with the word "MICROCOLOR" replaced by "hacked" -- used for testing the emulator's ability to load in another BASIC/OS ROM.

match_chr.bin is a simulated 768 byte character ROM, based on the NEC TREK's external character set image.

match_chrx.bin is a truncated 4K external character ROM, with character location matching the normal 6847 set, derived from the NEC TREK external character ROM.

mc10.bin is the BASIC ROM image for the MC-10 computer.  VMC-10 contains a copy of this built-in.

mess_ntscround_chr.bin is a simulated 768 byte character ROM, looted from MESS.

mess_ntscsquare_chr.bin is a simulated 768 byte character ROM, looted from MESS.

necpc_chrx.bin is the 4K external character ROM from the NEC PC-6001 (Japan) computer.  Check it with the Quicktyp/sg6.txt program.

nectrek_chrx is the 4K external character ROM from the NEC TREK computer.  Check it with the Quicktyp/sg6.txt program.

readme_r.txt is this file that you are reading right now.  Duh.
