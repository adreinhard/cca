16K required !!

code is at $4800 (18432)

so thats the EXEC address !!!

enjoy

/Simon :-P
