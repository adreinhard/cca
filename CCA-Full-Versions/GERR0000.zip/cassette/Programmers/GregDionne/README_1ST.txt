
The programs presented in this directory were
written by talented and dedicated
programmer Greg Dionne

Greg Dionne is a member of the Yahoo trs80mc10 group.
You should be one too.  What are you waiting for?

Kaleidoscope.c10 - demo
	CLOADM then EXEC

LprintPi.c10 - fun
	It prints PI.
	CLOADM then EXEC:n
	where n is the number of digits you want, up to 10,000.

Pac-Man.c10 - game
	Simply the best game EVER for the MC-10.
	CLOADM then EXEC
	Hit the BREAK key on the attract screen for greets
	Play using the "Emulated Keyboard" mode of the emulator
	Use the WASZ keys to maneuver
	You know how to play pac-man, don't you?

ReverseVideo.c10 - util
	CLOADM then EXEC
	Sets the BASIC editing screen to be light ink on dark background
	Does not go away with a soft reset!
	Wow, how did you do it, Greg!?

Tetris.c10 - game
	CLOADM then EXEC
	Excellent Tetris game, using multicolor graphics!
	Play using the "Emulated Keyboard" mode of the emulator
	Use the WASZ and Spacebar keys

Tetris4K.c10 - game
	CLOADM then EXEC
	Tetris, without a score display
	Works on a 4K unexpanded MC-10!!  How did you do it, Greg!?
	Play using the "Emulated Keyboard" mode of the emulator
	Use the WASZ and Spacebar keys
	