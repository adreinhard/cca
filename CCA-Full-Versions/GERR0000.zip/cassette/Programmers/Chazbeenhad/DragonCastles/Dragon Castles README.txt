Dragon Castles
A game for the TRS-80 MC-10 with 16K ram pak.
Program by Charles Pelosi ( chazbeenhad@hotmail.com )

Object of the game:

A terrible dragon is terrorizing a small kingdom of eight castles.
Your mission is to search the 8 castles for treasure and weapons.
Each piece of treasure or weapon you find increases your score.
Beware! The dragon is hidden in one of the castles. If your score is not equal
to or above the amount specified by the game level you chose, you lose the game
and the dragon wins! Also beware of the dragons �friends�.
If you happen to find one of them in a castle they won�t end your game,
but they will take away from your score. If your score is equal to or higher
than the amount specified by the game level and you find the dragon, you win the game !!

How to play:

After the intro screen you will be asked to pick a game level.
The number to the right is how high your score must be to be able to defeat the dragon
on that particular level. Level 1 requires a score of 300 or higher to win.

After selecting the game level, you are shown the main screen.
Here you simply enter the number of the castle you wish to search and press enter.
Notice on this screen you can see your score and how many turns you have taken.
The screen will also indicate if your score is high enough to defeat the dragon
should you find him.

After selecting the castle you want to search, the screen will show you a close up
of the castle and then what was found inside. Your score will then be added to or
taken away from depending on what you find !!
    
After this, if you did not win or lose by finding the dragon, you are taken back
to the main screen to choose again. Remember, all items are moving at random and
you are likely to find different items in different castles at each move.
This includes the dragon and his friends!

Notes:
Rolling an eight-sided die makes choosing a castle fun. These can be found in most
mall hobby stores.

Seems strange, that the dragon likes to hide in the red and orange castles a lot��

What is inside the .ZIP file:
This manual in MS word format.
This manual in text (.txt) format
The .wav file for recording to a cassette to play the game on your MC-10 !!
A .C10 file for use with the Virtual MC-10 emulator. (see links)
A .TXT of the program that could be used with the quick type feature of virtual MC-10.

Links:
Virtual MC-10: http://www.geocities.com/emucompboy/
Yahoo MC-10 group: http://groups.yahoo.com/group/trs80mc10club/

Charles Pelosi � chazbeenhad@hotmail.com 4/13/04

