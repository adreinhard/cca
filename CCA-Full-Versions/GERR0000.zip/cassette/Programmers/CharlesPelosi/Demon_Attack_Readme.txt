Demon Attack MC-10, a TRS-80 MC-10 game.

Object: 

Shoot the pesky demon and get a high score!

Controls:

Use "1" to move left
use "-" to move right
Use "Space Bar" to shoot


In the ZIP [unzipped in emulator archive]:

This readme file [you're reading it now].
DemonAttackMC10.wav to record to tape and load on your MC-10 [left out of emulator archive]!!
DemonAttackMC10.c10 for use with the emulator Virtual MC-10.
DemonAttackMC10.txt a list of the program. Can also be used with the quick type
feature of Virtual MC-10 [left out of emulator archive].

Links:

Charlie�s TRS-80 MC-10 web page: www.geocities.com/chazbeenhad
Yahoo MC-10 group: http://groups.yahoo.com/group/trs80mc10club/
Virtual MC-10: http://www.geocities.com/emucompboy/

5/20/04 chazbeenhad@hotmail.com
