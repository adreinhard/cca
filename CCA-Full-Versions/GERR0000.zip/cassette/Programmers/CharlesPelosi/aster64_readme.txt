
Aster64 by Rogelio Perea, modified by Charles Pelosi.

http://www.geocities.com/chazbeenhad/
Charles Pelosi's MC10 website




Rogelio Perea says:
After taking my MC-10 out of a drawer, I decided to re-run all those great
programs I wrote and copied from different sources. One I came upon is
particularly interesting, as I haven't seen any other application do as this
one does :-D

The following is an MC-10 program that enables (sort of) a graphics screen
of 64x64 resolution:
[ Program Listing Was Here ]

The program is based on the much used scroll-upwards screen effect of many
many games; the scenario is the usual one: Pilot a craft through an endless
stream of asteroids without getting hit. This time, the spacecraft resembles
the Enterprise of Star Trek fame.

After playing a lot with the MC-10 without any technical information on which
to base my experiments I started POKEing here and there, most of the time
locking up the computer; but then there were those moments when I found
something useful. You were told that BASIC only could produce Lo-Res 64x31
graphics and that to achieve more ML had to be used... well, no entirely so!.

One location I found that produced strange effects was LOC# 49151. When you
POKE a 4 in there the screen garbles up, you can "see" something moving
across when you type or list a program but that's that. After experimenting
by printing the entire CHR$ set on that screen I came up with a hefty list
of distinguishable characters (codes from 128 to 191) which correspond to
the original TRS-80 Model I and III block graphics characters, though they
do not have the same ASCII code.

What the program above does is declare all its variables, assign all
constants to a variable name and build the asteroid field. The body of
the program is in such a way that the main part of it is at the beginning
of the program list.... to speed up things a little bit.

To play the game use the 1 and - keys and the Enterprise will move in the
direction specified... watch out!! if you crash you actually see the ship
split apart in two directions (nice huh?).

One thing that I couldn't clean up is a flashing bar on the bottom of the
screen. This is due for two reasons:

a). When you print something on this screen the image unsettles a "bit". The
    asteroids are actually 31 STRING$ that include one asteroid in its
    particular position and the rest is filled up with black characters.

b). Did not have any technical info on the MC-10 (still don't) and this
    thing was "discovered" by me on a long cloudy evening.... hacking on
    this micro.

If someone has a technical insight on this subject please share it with all
of us (the CoCo Comunity). Yes, it has been a w-h-i-l-e since the MC-10 came
upon but there are still a lot of CoCo users that want to know a little "bit"
more of the CoCo family.

There is another file available with more information I prospected for in
the MC-10, and it contains the conversion table for the 128-191 block
graphics characters between the MC-10 and TRS-80 Model I & III computers and
some info on RAM locations that can be quite useful.

                             				Rogelio Perea



For any comments or suggestions please feel free to contact me, and remember:
                   NO SASE required if you want a reply!!
                   ^^^^^^^