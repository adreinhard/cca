Appeared Australian MiCo July 1985
TABLES by Graeme Pollock

It must be twenty years now since my father drilled my older brother and I on our tables. We had to know them forwards, backwards and upside-down.

We weren't too keen on those drilling sessions at the time, but dad certainly achieved his objective. As I remember, we used to get into a bit of trouble if we
didn't know then(boy! are you lucky,  the computer doesn't wear a belt to hold its trousers up!).

As it turned out, we both did 3 years o-f math's at Uni. I now believe that a good drilling in tables is essential. Thanks dad!!

"TABLES" is a program that will give you a good drilling on your tables (without shouting at you). It's only a short program but it has 'substance' (I was going to say "guts" but I won't).

I've seen a few programs with fancy titles and frill-dills but N0 SUBSTANCE. This one's got
no frills. If you want, you can add your own.

In '"TABLES", you are asked what tables you want to practice (or is it 'practice'? ) in line 10. You can choose ANY tables you want (even 0.5 times tables).

You are then shown the complete set for those tables (line 20) and you are allowed as much tine as you want to study them. After you press enter, you are given a random question to answer from the tables you choose (lines 60, 70, 80). If you get it right, you get a reward (lines 90, 200, 210) and a chance to try a new question (line 220).

If you get it wrong, then you are given more tine to study the tables(lines l00,120,125) and you get to answer the sane question again (linel30). You will not be asked a new question until you get that one right.

If you want to drill on a new set of tables then you will need to BREAK and RUN.

If you want to triple CSAVE the program then RUN3.

Note that line 5 serves 2 purposes. Firstly, it gives a title set of screens and secondly, it makes certain that the first random question is not the sane every tine.
See what you can do to jazz it up a bit!!
Bye for now !!!!!

