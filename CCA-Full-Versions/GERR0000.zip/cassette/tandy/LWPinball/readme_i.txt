If you're reading this with Notepad, set word wrap to "on."


Quick instructions for Lost World Pinball:

This game requires a 16K RAM expander.  On the emulator, find Memory under the Configuration menu.  Check the "+ 16K RAM expansion" box and click OK.  For a real MC-10, you'll need a real RAM expansion cartridge.  Buy one on E-Bay if you don't have one.

This game is a cassette file.  To use, type
CLOADM
 and start the cassette going.  (On the emulator, use the "Play Cassette File" from the file menu).  When the blinking cursor returns, type 
EXEC

To play on the emulator, you will need to set the emulator to use the "emulated" keyboard mode;  to do that, from the Config menu select Keyboard.  This brings up the keyboard configuration dialog box.  Check the "Emulated" radio button, and click on "Okay."  (When you're done playing, you may want to set the keyboard mode back to "sensible.")

At the title screen, whack the space bar.  

Hold down the ENTER key to pull the launcher back, and release it to launch the ball.  After that, the CONTROL key controls the left flipper and the SHIFT key controls the right flipper.

You can reset the game by pressing the BREAK key (on the emulator, that's the Esc key) while the ball is in play.

When you run out of balls, the high score board is supposed to flash.

You get points for hitting orange things except for the end hole and the flipper hubs.  There's all sorts of nifty scoring bonuses and event things which happen, but since you can't "aim" the ball or "nudge" the table, achieving these things is a matter of luck.  For example, "to make the volcan erupt, the dinosaur Vally has to catch the prehistoric fly with his tongue.  To get the tongue to the right length, you must hit the orange marks set up by the top four plungers twelve times."  Yeah right.  This is about as likely to happen as me winning the California State Super Lotto.

Have fun playing this flawed and possibly buggy game -- then play Pinball for the Atari 2600, which does have "nudge," and see how good a limited system pinball can be.

========

Tape source - James
The digitizing process is never perfect.
Confidence: excellent -- the tape contains four images of the game.  Two matched.


