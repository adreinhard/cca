If you're reading this with Notepad, set word wrap to "on."


Quick instructions for Compac (mccom.c10):

This program is a cassette file.  To use, type
CLOADM
 and start the cassette going.  (On the emulator, use the "Play Cassette File" from the file menu).  When the blinking cursor returns, type 
EXEC


Beyond that, I know nothing.  You can find docs for this program on 
http://mymc10.tripod.com/

The emulator does not emulate any modem serial communication, so beyond looking at the configuration screen, there's nothing you can do.

========

Tape source - I don't remember -- probably Mr Wizard of mymc10.tripod.com
The digitizing process is never perfect.
Confidence: low, made from a single low-speed instance

