
Gary Furr's extended BASIC for MC-10.

Requires a 16K RAM expander on the real MC-10.
On the emulator, the memory must be configured
to Normal +16K RAM ("enhanced" will not work).

Read the documentation in the PDF file.

Home page for Extended BASIC is here:

http://users.bigpond.net.au/jagf/mc10.html
