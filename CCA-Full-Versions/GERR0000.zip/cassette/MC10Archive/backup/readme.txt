BACKUP by Gary Furr
-------------------
Used to BACKUP programs.
Program appeared in �Softgold� Australian CoCo magazine in 1987 (magazine wasn�t dated)

Usage:
EXEC. Press any key to start program. 
Load the program to be copied. 
When the �SAVING� appears press any key to CSAVE.

Notes:
The program will copy both BASIC and M.L. Programs won�t overwrite BACKUP, as it is located below BASIC.
EXEC address 17090

Included in this archive:
backup.wav 148KB - WAV File. Generated using C10TOWAV program
backup.c10 1KB - Emulator file
readme.txt 1KB - This file