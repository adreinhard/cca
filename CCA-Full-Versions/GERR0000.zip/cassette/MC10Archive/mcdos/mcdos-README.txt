MCDOS by Grahame Pollock 1986
-----------------------------
File: MACHINE LANGUAGE
Included are two sample RAM DISK files.

This is a method of saving a disk file of programs into the memory and then saving them to tape. Yes a RAM DISK.

I have played around with this program (for the first time), and have taken down some notes which you may find helpful.

After loading MCDOS <EXEC>
Press <ENTER> (might take a couple of presses)

To create your RAM DISK
Select option 6
CLOAD  your basic program then enter DOS
Select option 1

Continue until you have desired amount of files stored in RAM.
Option 3 will save your RAM DISK

------------------

To LOAD MCDOS, CLOADM, EXEC and then press ENTER for the menu. This gives 6 options.

1. Add program to file. 
2. View Dir. 
3. Save to tape. 
4. Delete last program
5. Load disk
6. Exit to Basic.

To access MCDOS main menu from BASIC you simply need to type in DOS and press <enter>.

Option 1. will add the current BASIC program into the disk file.
Option  2. will allow you to see the names of the programs in the disk file. Choose your program by pressing the letter in front of it.
Option  3. will allow you to save the disk file to tape.
Option  4. will delete the last program from the file.
Option  5. will load a new disk file into memory from tape.
Option 6 allows you to return to BASIC so you can CLOAD a program into BASIC memory or SKIPF to position  the tape.

