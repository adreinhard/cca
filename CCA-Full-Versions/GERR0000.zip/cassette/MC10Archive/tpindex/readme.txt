TAPE INDEX by Graham Pollock
Appeared in Australian CoCo September 1985

Tape Index is a program that will allow you to scan through a tape and find out about the programs on it.  To do this it will SKIPF through the tape and look at some storage addresses in RAM after  each   program has gone past.

The program filename is stored between addresses 16991 ($425F) and 16998 ($4266).  The program type is stored at address 16999 ($4267).  The 3 types of  programs are identified by their own file type number.-
             0 means BASIC
             2 means MACHINE LANGUAGE
             4 means NUMERICAL ARRAY

The addresses 17004($426c) and 17005 ($426d) hold the program length for BASIC and array types, and the start address for M.L. programs. If you have a printer you may choose to have a hard copy of your tape index. There is only one problem. It won't give you the length of BASIC programs on MICOOZ (but it will TOM LEHANES tapes CSAVED with the MC-10 emulator, COCO-MICO).
