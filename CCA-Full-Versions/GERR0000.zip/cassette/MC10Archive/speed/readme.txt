SPEED by G.POLLOCK
---------------------
Slows down the display of text to the screen.

This program appeared in the MC-10 Users Group magazine February 1986.

Included in this archive:
LLIST.txt 1KB - LLISTing of program
speed.WAV 292KB - WAV File. Generated using C10TOWAV program
speed.c10 2KB - Emulator file
readme.txt 1KB - This file    

Program listings compile by G.FURR 2004
Compiled using Notepad