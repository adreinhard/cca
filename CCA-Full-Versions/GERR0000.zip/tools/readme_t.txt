A few tools to help you work with the emulator.

========================

DC - Dragon Convert.  This is a program which will convert a WAV file to a CAS file.  You'll need an MS-DOS prompt to use it.  I've tried it with mono WAVs.  It works best if the WAV file you're using has an amplitude great enough so that most peaks clip.  Good luck.  DC messes with the synch bytes -- FIXCAS will fix those.  When using FIXCAS with MC-10 files, use synch parameters of 128 0 to output a C10 file

dc wavename
fixcas casname c10name 128 0

-
dc program by P.Burgin, 1997
========================

FIXCAS - see DC (Dragon Convert) above.

-
fixcas program by Graham E. Kinns, 1993
========================

MONOWAV - This program takes a 44100 Hz .WAV 8-bit stereo WAV file and converts it into two mono WAV files.  It saves the new WAV files in the same directory as the original.
The 'Process all WAVs in the browsed directory and all subdirs' option will attempt to convert all WAV files in the same directory as the file chosen... and then will search through all subdirectories for more WAV files to convert.  Don't try this unless you REALLY want to convert all the files in all the subdirectories!

-
monowav program by James the Animal Tamer
========================

C10TOWAV - This program takes a good .c10 file and converts it into a WAV file.  The WAV file can be used with a real MC10 computer.  It's a Windows program -- double click the icon to open it and get started.

-
c10towav program by James the Animal Tamer
========================


