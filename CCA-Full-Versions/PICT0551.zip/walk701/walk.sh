#!/bin/csh
# Unix script to run the walkthrough automatically
# N.B. The terminal should have 80 columns and at least 24 rows.
# The line after the 'tadsr' command should contain 10 spaces.
rm -f game701.log

tadsr polyadv.gam <<END
          
script "game701.log"
@walk0.txt
@walk1.txt
@walk2.txt
@walk3.txt
@walk4.txt
@walk5.txt
@walk6.txt
quit
yes
\$\$ABEND

END
