#!/bin/csh
# Unix script to run the walkthrough automatically
# N.B. The terminal should have 80 columns and at least 24 rows.
# The line after the 'tadsr' command should contain 10 spaces.

# special version to test compatibility of the game701+ mode (which should be
# *almost* the same as the game701 mode provided that the steel door is not
# unlocked)

rm -f game701a.log

tadsr polyadv.gam <<END
          
script "game701a.log"
@walk0a.txt
@walk1.txt
@walk2.txt
@walk3.txt
@walk4.txt
@walk5.txt
@walk6.txt
quit
yes
\$\$ABEND

END
