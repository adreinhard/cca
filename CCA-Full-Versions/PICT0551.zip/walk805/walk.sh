#!/bin/csh
# Unix script to run the walkthrough for the 701+ point game with an
# 805-point finish. (This includes the hard-to-get platinum bars.  Hint: to get
# this treasure, you'll need to investigate the castle more thoroughly than
# usual.)

# N.B. The terminal should have 80 columns and at least 24 rows.
# The line after the 'tadsr' command should contain 10 spaces.
rm -f game805.log

tadsr polyadv.gam <<END
          
script "game805.log"
@walk1.txt
@walk2.txt
@walk3.txt
@walk4.txt
@walk5.txt
@walk6.txt
@walk7.txt
@walk8.txt
@walk9.txt
@walk10.txt
quit
yes
\$\$ABEND

END
