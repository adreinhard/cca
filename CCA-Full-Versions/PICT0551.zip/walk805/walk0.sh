#!/bin/csh
# Unix script to run the walkthrough automatically
# N.B. The terminal should have 80 columns and at least 24 rows.
# The line after the 'tadsr' command should contain 10 spaces.

# Test of variant endgame (zero points due to omission of essential action
# earlier in game)

rm -f game0.log

tadsr polyadv.gam <<END
          
script "game0.log"
@walk1.txt
@walk2.txt
@walk3.txt
@walk4.txt
@walk5.txt
@walk6.txt
@walk7.txt
@walk8.txt
@walk9a.txt
@walk10.txt
quit
yes
\$\$ABEND

END
