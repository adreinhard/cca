#!/bin/csh
# Unix script to run the walkthrough for the 701+ point game with a 
# 793-point finish.  (This includes the optional iridium sphere but not the 
# platinum bars.)

# N.B. The terminal should have 80 columns and at least 24 rows.
# The line after the 'tadsr' command should contain 10 spaces.
rm -f game793.log

tadsr polyadv.gam <<END
          
script "game793.log"
@walk1.txt
@walk2.txt
@walk3.txt
@walk4.txt
@walk5.txt
@walk6.txt
@walk7.txt
@walk8.txt
quit
yes
\$\$ABEND

END
