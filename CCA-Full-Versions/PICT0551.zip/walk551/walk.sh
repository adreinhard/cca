#!/bin/csh
# Unix script to run the walkthrough automatically
# N.B. The terminal should have 80 columns and at least 24 rows.
# The line after the 'tadsr' command should contain 10 spaces.
rm -f game551.log

tadsr polyadv.gam <<END
          
script "game551.log"
@walk1.txt
@walk2.txt
@walk3.txt
@walk4.txt
quit
yes
\$\$ABEND

END
