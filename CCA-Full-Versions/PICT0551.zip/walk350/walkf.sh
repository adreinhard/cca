#!/bin/csh
# Script to run the walkthrough automatically
# N.B. The terminal should have 80 columns and at least 24 rows.
# The line after the 'tadsr' command should contain 10 spaces.
rm -f game350.log

frob polyadv.gam <<END
          
script "game350.log"
@walk.txt
quit
yes
\$\$ABEND

END
